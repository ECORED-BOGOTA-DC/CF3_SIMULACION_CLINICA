function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6Tkok3Aq0IV":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

